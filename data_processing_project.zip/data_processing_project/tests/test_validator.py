"""Unit tests. Run with:  python -m unittest discover -s tests -v"""

import sys
import unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from data_processor.summarizer import summarize
from data_processor.validator import validate_all, validate_record

TODAY = date(2026, 11, 2)


def good_row(**overrides):
    row = {"order_id": "ORD-1001", "customer_name": "Asha", "product": "Mouse",
           "category": "Electronics", "quantity": "2", "unit_price": "10.50",
           "order_date": "2026-01-01", "region": "North"}
    row.update(overrides)
    return row


class ValidatorTests(unittest.TestCase):
    def test_valid_record(self):
        rec, rej = validate_record(good_row(), 2, TODAY)
        self.assertIsNone(rej)
        self.assertEqual(rec.total, 21.00)

    def test_missing_field(self):
        rec, rej = validate_record(good_row(customer_name=""), 2, TODAY)
        self.assertIsNone(rec)
        self.assertEqual(rej.errors[0][0], "customer_name")

    def test_bad_types_and_ranges(self):
        for field, value in [("quantity", "abc"), ("quantity", "0"), ("unit_price", "-5"),
                             ("unit_price", "nan"), ("order_date", "01/02/2026"),
                             ("order_date", "2027-01-01"), ("category", "Toys"),
                             ("region", "Central"), ("order_id", "X-1")]:
            with self.subTest(field=field, value=value):
                rec, rej = validate_record(good_row(**{field: value}), 2, TODAY)
                self.assertIsNone(rec)
                self.assertIn(field, [f for f, _ in rej.errors])

    def test_multiple_errors_collected(self):
        _, rej = validate_record(good_row(quantity="x", region=""), 2, TODAY)
        self.assertEqual(len(rej.errors), 2)

    def test_duplicates_rejected(self):
        valid, rejected = validate_all([(2, good_row()), (3, good_row())], TODAY)
        self.assertEqual((len(valid), len(rejected)), (1, 1))

    def test_summary(self):
        valid, rejected = validate_all([(2, good_row()), (3, good_row(order_id="ORD-1002", quantity="x"))], TODAY)
        s = summarize(valid, rejected)
        self.assertEqual(s["validity_rate_percent"], 50.0)
        self.assertEqual(s["revenue"]["total"], 21.0)

    def test_empty_summary(self):
        s = summarize([], [])
        self.assertIsNone(s["revenue"])


if __name__ == "__main__":
    unittest.main()
