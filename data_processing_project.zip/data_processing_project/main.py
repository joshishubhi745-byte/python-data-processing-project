#!/usr/bin/env python3
"""Command-line entry point for the Data Processing Project.

Example:
    python main.py --input data/input.csv --output output
"""

import argparse
import logging
import sys
from pathlib import Path

from data_processor.exporter import ExportError, export_all
from data_processor.reader import InputFileError, read_records
from data_processor.summarizer import summarize
from data_processor.validator import validate_all


def configure_logging(log_dir: Path, verbose: bool) -> None:
    """Log to the terminal and to logs/processing.log."""
    log_dir.mkdir(parents=True, exist_ok=True)
    fmt = "%(asctime)s | %(levelname)-8s | %(message)s"
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format=fmt, datefmt="%H:%M:%S",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_dir / "processing.log", mode="w", encoding="utf-8"),
        ],
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate, summarise and report on order data.")
    parser.add_argument("-i", "--input", type=Path, default=Path("data/input.csv"),
                        help="input .csv or .json file (default: data/input.csv)")
    parser.add_argument("-o", "--output", type=Path, default=Path("output"),
                        help="output directory (default: output)")
    parser.add_argument("-l", "--log-dir", type=Path, default=Path("logs"),
                        help="log directory (default: logs)")
    parser.add_argument("-v", "--verbose", action="store_true", help="enable debug logging")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    configure_logging(args.log_dir, args.verbose)
    log = logging.getLogger("main")

    try:
        log.info("Starting run on %s", args.input)
        rows = read_records(args.input)
        valid, rejected = validate_all(rows)
        summary = summarize(valid, rejected)
        paths = export_all(args.output, summary, valid, rejected, args.input.name)
    except (InputFileError, ExportError) as exc:
        log.error("%s", exc)
        return 1
    except Exception:  # Last-resort guard so users get a clean message + traceback in the log.
        log.exception("Unexpected failure")
        return 2

    print("\n" + "-" * 62)
    print(f"Processed {summary['total_records']} record(s): "
          f"{summary['valid_records']} valid, {summary['rejected_records']} rejected "
          f"({summary['validity_rate_percent']}% valid)")
    if summary.get("revenue"):
        print(f"Total revenue from valid orders: {summary['revenue']['total']:,.2f}")
    print("Output files:")
    for p in paths:
        print(f"  - {p}")
    print("-" * 62)
    return 0


if __name__ == "__main__":
    sys.exit(main())
