"""Reading and parsing of structured input files (CSV and JSON)."""

import csv
import json
import logging
from pathlib import Path
from typing import Dict, Iterator, List, Tuple

from .validator import REQUIRED_FIELDS

logger = logging.getLogger(__name__)

Row = Dict[str, object]


class InputFileError(Exception):
    """Raised when the input file cannot be read or has an unusable structure."""


def read_records(path: Path) -> List[Tuple[int, Row]]:
    """Read a CSV or JSON file and return a list of (record_number, row) tuples.

    ``record_number`` is the line number for CSV files (header = line 1) and the
    1-based position in the array for JSON files, so users can find bad rows fast.
    """
    path = Path(path)
    if not path.exists():
        raise InputFileError(f"Input file not found: {path}")
    if not path.is_file():
        raise InputFileError(f"Input path is not a file: {path}")

    suffix = path.suffix.lower()
    try:
        if suffix == ".csv":
            records = list(_read_csv(path))
        elif suffix == ".json":
            records = list(_read_json(path))
        else:
            raise InputFileError(
                f"Unsupported file type '{suffix}'. Use a .csv or .json file."
            )
    except UnicodeDecodeError as exc:
        raise InputFileError(f"File is not valid UTF-8 text: {exc}") from exc
    except OSError as exc:
        raise InputFileError(f"Could not read '{path}': {exc}") from exc

    logger.info("Read %d record(s) from %s", len(records), path)
    return records


def _read_csv(path: Path) -> Iterator[Tuple[int, Row]]:
    # utf-8-sig transparently strips the BOM that Excel adds to CSV exports.
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise InputFileError("CSV file is empty (no header row found).")

        headers = {name.strip() for name in reader.fieldnames if name}
        missing = [f for f in REQUIRED_FIELDS if f not in headers]
        if missing:
            raise InputFileError(f"CSV is missing required column(s): {', '.join(missing)}")

        try:
            for row in reader:
                # Drop the None key csv uses for extra columns; strip header whitespace.
                clean = {k.strip(): v for k, v in row.items() if k is not None}
                yield reader.line_num, clean
        except csv.Error as exc:
            raise InputFileError(f"Malformed CSV near line {reader.line_num}: {exc}") from exc


def _read_json(path: Path) -> Iterator[Tuple[int, Row]]:
    with path.open("r", encoding="utf-8-sig") as handle:
        try:
            data = json.load(handle)
        except json.JSONDecodeError as exc:
            raise InputFileError(f"Invalid JSON: {exc}") from exc

    if not isinstance(data, list):
        raise InputFileError("JSON input must be an array of objects.")

    for index, item in enumerate(data, start=1):
        # Non-object entries become empty rows so the validator reports them.
        yield index, item if isinstance(item, dict) else {}
