"""Summarising validated records into meaningful statistics."""

import statistics
from collections import Counter, defaultdict
from typing import Any, Dict, List

from .validator import RejectedRecord, ValidRecord


def summarize(valid: List[ValidRecord], rejected: List[RejectedRecord]) -> Dict[str, Any]:
    """Build a JSON-serialisable summary of the run."""
    total_rows = len(valid) + len(rejected)
    summary: Dict[str, Any] = {
        "total_records": total_rows,
        "valid_records": len(valid),
        "rejected_records": len(rejected),
        "validity_rate_percent": round(100 * len(valid) / total_rows, 2) if total_rows else 0.0,
        "rejection_reasons_by_field": dict(
            Counter(field for r in rejected for field, _ in r.errors).most_common()
        ),
    }

    if not valid:
        summary["revenue"] = None
        return summary

    totals = [r.total for r in valid]
    summary["revenue"] = {
        "total": round(sum(totals), 2),
        "average_order_value": round(statistics.mean(totals), 2),
        "median_order_value": round(statistics.median(totals), 2),
        "largest_order": {"order_id": max(valid, key=lambda r: r.total).order_id, "value": max(totals)},
        "smallest_order": {"order_id": min(valid, key=lambda r: r.total).order_id, "value": min(totals)},
    }
    summary["total_units_sold"] = sum(r.quantity for r in valid)
    summary["by_category"] = _group(valid, lambda r: r.category)
    summary["by_region"] = _group(valid, lambda r: r.region)
    summary["by_month"] = dict(sorted(_group(valid, lambda r: r.order_date.strftime("%Y-%m")).items()))
    summary["top_products"] = _top_products(valid, limit=5)
    return summary


def _group(records: List[ValidRecord], key) -> Dict[str, Dict[str, float]]:
    """Group records by ``key`` and compute order count and revenue per group."""
    groups: Dict[str, Dict[str, float]] = defaultdict(lambda: {"orders": 0, "revenue": 0.0})
    for rec in records:
        bucket = groups[key(rec)]
        bucket["orders"] += 1
        bucket["revenue"] = round(bucket["revenue"] + rec.total, 2)
    # Highest revenue first
    return dict(sorted(groups.items(), key=lambda kv: kv[1]["revenue"], reverse=True))


def _top_products(records: List[ValidRecord], limit: int) -> List[Dict[str, Any]]:
    revenue: Dict[str, float] = defaultdict(float)
    units: Dict[str, int] = defaultdict(int)
    for rec in records:
        revenue[rec.product] += rec.total
        units[rec.product] += rec.quantity
    ranked = sorted(revenue.items(), key=lambda kv: kv[1], reverse=True)[:limit]
    return [{"product": p, "units": units[p], "revenue": round(v, 2)} for p, v in ranked]
