"""Exporting results: JSON summary, text report and CSV files."""

import csv
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from .validator import REQUIRED_FIELDS, RejectedRecord, ValidRecord

logger = logging.getLogger(__name__)


class ExportError(Exception):
    """Raised when a report file cannot be written."""


def export_all(
    output_dir: Path,
    summary: Dict[str, Any],
    valid: List[ValidRecord],
    rejected: List[RejectedRecord],
    source_name: str,
) -> List[Path]:
    """Write every output file and return their paths."""
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
        paths = [
            _write_json(output_dir / "summary.json", summary),
            _write_text_report(output_dir / "report.txt", summary, source_name),
            _write_valid_csv(output_dir / "valid_records.csv", valid),
            _write_rejected_csv(output_dir / "rejected_records.csv", rejected),
        ]
    except OSError as exc:
        raise ExportError(f"Could not write output files to '{output_dir}': {exc}") from exc
    for p in paths:
        logger.info("Wrote %s", p)
    return paths


def _write_json(path: Path, summary: Dict[str, Any]) -> Path:
    with path.open("w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2, ensure_ascii=False)
        fh.write("\n")
    return path


def _write_valid_csv(path: Path, valid: List[ValidRecord]) -> Path:
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(list(REQUIRED_FIELDS) + ["order_total"])
        for r in valid:
            writer.writerow([r.order_id, r.customer_name, r.product, r.category, r.quantity,
                             f"{r.unit_price:.2f}", r.order_date.isoformat(), r.region,
                             f"{r.total:.2f}"])
    return path


def _write_rejected_csv(path: Path, rejected: List[RejectedRecord]) -> Path:
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["line", "order_id", "reasons"] + list(REQUIRED_FIELDS))
        for r in rejected:
            writer.writerow([r.line, r.order_id, r.reason_text] +
                            ["" if r.raw.get(k) is None else r.raw.get(k) for k in REQUIRED_FIELDS])
    return path


def _money(value: float) -> str:
    return f"{value:,.2f}"


def _write_text_report(path: Path, s: Dict[str, Any], source_name: str) -> Path:
    lines: List[str] = []
    bar = "=" * 62
    lines += [bar, "  ORDER DATA PROCESSING REPORT", bar,
              f"  Source file : {source_name}",
              f"  Generated   : {datetime.now():%Y-%m-%d %H:%M:%S}", "",
              "DATA QUALITY", "-" * 62,
              f"  Total records     : {s['total_records']}",
              f"  Valid records     : {s['valid_records']}",
              f"  Rejected records  : {s['rejected_records']}",
              f"  Validity rate     : {s['validity_rate_percent']}%"]
    if s["rejection_reasons_by_field"]:
        lines.append("  Rejections by field:")
        lines += [f"    - {f:<14} {n}" for f, n in s["rejection_reasons_by_field"].items()]

    rev = s.get("revenue")
    if rev:
        lines += ["", "REVENUE", "-" * 62,
                  f"  Total revenue       : {_money(rev['total'])}",
                  f"  Average order value : {_money(rev['average_order_value'])}",
                  f"  Median order value  : {_money(rev['median_order_value'])}",
                  f"  Largest order       : {rev['largest_order']['order_id']} ({_money(rev['largest_order']['value'])})",
                  f"  Smallest order      : {rev['smallest_order']['order_id']} ({_money(rev['smallest_order']['value'])})",
                  f"  Total units sold    : {s['total_units_sold']}"]
        for title, key in (("BY CATEGORY", "by_category"), ("BY REGION", "by_region"), ("BY MONTH", "by_month")):
            lines += ["", title, "-" * 62, f"  {'Group':<16}{'Orders':>8}{'Revenue':>18}"]
            lines += [f"  {name:<16}{g['orders']:>8}{_money(g['revenue']):>18}" for name, g in s[key].items()]
        lines += ["", "TOP PRODUCTS BY REVENUE", "-" * 62, f"  {'Product':<30}{'Units':>6}{'Revenue':>16}"]
        lines += [f"  {p['product']:<30}{p['units']:>6}{_money(p['revenue']):>16}" for p in s["top_products"]]
    else:
        lines += ["", "No valid records, so no revenue statistics are available."]

    lines += ["", bar, "  See rejected_records.csv for details on every invalid row.", bar, ""]
    path.write_text("\n".join(lines), encoding="utf-8")
    return path
