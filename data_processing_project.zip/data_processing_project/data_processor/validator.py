"""Validation of individual records against business rules."""

import logging
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

REQUIRED_FIELDS = (
    "order_id", "customer_name", "product", "category",
    "quantity", "unit_price", "order_date", "region",
)

# ---- Business rules (edit these to change what counts as valid) -------------
ORDER_ID_PATTERN = re.compile(r"^ORD-\d{4}$")
ALLOWED_CATEGORIES = {"Electronics", "Books", "Clothing", "Home", "Sports"}
ALLOWED_REGIONS = {"North", "South", "East", "West"}
MIN_QUANTITY, MAX_QUANTITY = 1, 1000
MIN_PRICE, MAX_PRICE = 0.01, 100_000.00
EARLIEST_DATE = date(2020, 1, 1)
MAX_NAME_LENGTH = 60
# -----------------------------------------------------------------------------


@dataclass
class ValidRecord:
    """A fully validated and type-converted order."""
    order_id: str
    customer_name: str
    product: str
    category: str
    quantity: int
    unit_price: float
    order_date: date
    region: str

    @property
    def total(self) -> float:
        return round(self.quantity * self.unit_price, 2)


@dataclass
class RejectedRecord:
    """An invalid record together with every reason it failed."""
    line: int
    order_id: str
    errors: List[Tuple[str, str]] = field(default_factory=list)  # (field, message)
    raw: Dict[str, object] = field(default_factory=dict)

    @property
    def reason_text(self) -> str:
        return "; ".join(f"{f}: {m}" for f, m in self.errors)


def _text(row: Dict[str, object], key: str) -> str:
    """Return a stripped string for a field, treating None as empty."""
    value = row.get(key)
    return "" if value is None else str(value).strip()


def validate_record(
    row: Dict[str, object], line: int, today: Optional[date] = None
) -> Tuple[Optional[ValidRecord], Optional[RejectedRecord]]:
    """Validate one row. Returns (ValidRecord, None) or (None, RejectedRecord).

    All problems in the row are collected so the user can fix them in one pass.
    """
    today = today or date.today()
    errors: List[Tuple[str, str]] = []

    # Required text fields -----------------------------------------------------
    order_id = _text(row, "order_id")
    if not order_id:
        errors.append(("order_id", "missing value"))
    elif not ORDER_ID_PATTERN.match(order_id):
        errors.append(("order_id", f"'{order_id}' does not match format ORD-0000"))

    customer = _text(row, "customer_name")
    if not customer:
        errors.append(("customer_name", "missing value"))
    elif len(customer) > MAX_NAME_LENGTH:
        errors.append(("customer_name", f"longer than {MAX_NAME_LENGTH} characters"))

    product = _text(row, "product")
    if not product:
        errors.append(("product", "missing value"))

    category = _text(row, "category")
    if not category:
        errors.append(("category", "missing value"))
    elif category not in ALLOWED_CATEGORIES:
        errors.append(("category", f"'{category}' is not an allowed category"))

    region = _text(row, "region")
    if not region:
        errors.append(("region", "missing value"))
    elif region not in ALLOWED_REGIONS:
        errors.append(("region", f"'{region}' is not an allowed region"))

    # Quantity: integer within range --------------------------------------------
    quantity: Optional[int] = None
    raw_qty = _text(row, "quantity")
    if not raw_qty:
        errors.append(("quantity", "missing value"))
    else:
        try:
            quantity = int(raw_qty)
            if not MIN_QUANTITY <= quantity <= MAX_QUANTITY:
                errors.append(
                    ("quantity", f"{quantity} outside range {MIN_QUANTITY}-{MAX_QUANTITY}")
                )
        except ValueError:
            errors.append(("quantity", f"'{raw_qty}' is not a whole number"))

    # Unit price: positive number within range ----------------------------------
    unit_price: Optional[float] = None
    raw_price = _text(row, "unit_price")
    if not raw_price:
        errors.append(("unit_price", "missing value"))
    else:
        try:
            unit_price = float(raw_price)
            if unit_price != unit_price or unit_price in (float("inf"), float("-inf")):
                raise ValueError("not finite")
            if not MIN_PRICE <= unit_price <= MAX_PRICE:
                errors.append(
                    ("unit_price", f"{unit_price} outside range {MIN_PRICE}-{MAX_PRICE}")
                )
        except ValueError:
            errors.append(("unit_price", f"'{raw_price}' is not a valid number"))

    # Order date: ISO format, not in the future ---------------------------------
    order_date: Optional[date] = None
    raw_date = _text(row, "order_date")
    if not raw_date:
        errors.append(("order_date", "missing value"))
    else:
        try:
            order_date = datetime.strptime(raw_date, "%Y-%m-%d").date()
            if order_date > today:
                errors.append(("order_date", f"{raw_date} is in the future"))
            elif order_date < EARLIEST_DATE:
                errors.append(("order_date", f"{raw_date} is before {EARLIEST_DATE}"))
        except ValueError:
            errors.append(("order_date", f"'{raw_date}' is not in YYYY-MM-DD format"))

    if errors:
        return None, RejectedRecord(line=line, order_id=order_id, errors=errors,
                                    raw={k: row.get(k) for k in REQUIRED_FIELDS})

    return ValidRecord(
        order_id=order_id, customer_name=customer, product=product,
        category=category, quantity=quantity, unit_price=round(unit_price, 2),
        order_date=order_date, region=region,
    ), None


def validate_all(
    rows: List[Tuple[int, Dict[str, object]]], today: Optional[date] = None
) -> Tuple[List[ValidRecord], List[RejectedRecord]]:
    """Validate every row, also rejecting duplicate order IDs (first one wins)."""
    valid: List[ValidRecord] = []
    rejected: List[RejectedRecord] = []
    seen_ids: Set[str] = set()

    for line, row in rows:
        try:
            record, rejection = validate_record(row, line, today)
        except Exception as exc:  # Defensive: one bad row must never crash the run.
            logger.exception("Unexpected error validating line %d", line)
            rejection = RejectedRecord(line=line, order_id="", errors=[("record", f"unexpected error: {exc}")])
            record = None

        if record is not None:
            if record.order_id in seen_ids:
                rejection = RejectedRecord(
                    line=line, order_id=record.order_id,
                    errors=[("order_id", f"duplicate of an earlier record ({record.order_id})")],
                    raw={k: row.get(k) for k in REQUIRED_FIELDS},
                )
                record = None
            else:
                seen_ids.add(record.order_id)

        if record is not None:
            valid.append(record)
        else:
            rejected.append(rejection)
            logger.warning("Line %d rejected (%s): %s", line, rejection.order_id or "no id",
                           rejection.reason_text)

    logger.info("Validation complete: %d valid, %d rejected", len(valid), len(rejected))
    return valid, rejected
