"""Data Processing Project: read, validate, summarize and export records."""

__version__ = "1.0.0"
